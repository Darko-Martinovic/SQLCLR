﻿
EXEC [EMAIL].[CLRSendMail]	@profileName = N'SimpleTalk'
						,@mailTo = N'darko.martinovic@outlook.hr'
						,@mailSubject = N'Slanje putem outlooka'
						,@mailBody = N'Outlook';
