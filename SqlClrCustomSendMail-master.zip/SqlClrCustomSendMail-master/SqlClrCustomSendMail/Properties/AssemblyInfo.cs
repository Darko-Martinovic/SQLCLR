﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with the SQLCLR assembly.
[assembly: AssemblyTitle("SimpleTalk SQLCLR Custom Send Message")]
[assembly: AssemblyDescription("Send e-mails by using SQLCLR")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Darko Martinovic")]
[assembly: AssemblyProduct("SimpleTalk.SQLCLR.SendMail")]
[assembly: AssemblyCopyright("Darko Martinovic")]
[assembly: AssemblyTrademark("Darko Martinovic")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
