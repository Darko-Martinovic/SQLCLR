﻿SELECT
	*
FROM email.CustomSendMailHelp('email.clrsendmail')


